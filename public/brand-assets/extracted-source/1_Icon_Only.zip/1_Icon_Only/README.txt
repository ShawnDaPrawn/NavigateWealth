Navigate_Wealth_Icon_Only

Source:
These packs were rebuilt from the exact approved logo artwork shown in the ChatGPT image you selected.

Included formats:
- PNG (transparent)
- PNG @2x (transparent)
- JPG (white background)
- WEBP (transparent)
- PDF
- SVG

Note on SVG:
The SVG file is an embedded-image SVG wrapper around the approved PNG artwork.
It preserves the exact look of the approved design, but it is not a fully redrawn vector logo.
